package classifier;

import hierarchy.Category;

public class ClassifyResult {
	@Override
	public String toString() {
		return "[category=" + category.getName() + ", coverage="
				+ coverage + ", speciality=" + speciality + "]";
	}

	private final Category category;
	private final int coverage;
	private final double speciality;
	
	public ClassifyResult(Category c, int cover, double spec) {	
		category = c;
		coverage = cover;
		speciality = spec;
	}
	
	public Category getCategory() {
		return category;
	}

	public int getCoverage() {
		return coverage;
	}

	public double getSpeciality() {
		return speciality;
	}
}
