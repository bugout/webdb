#!/bin/sh

java -cp ".:lib/*" Test "${1}" $2 ${3} "${4}"